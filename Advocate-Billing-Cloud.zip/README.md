# Advocate Billing Cloud — Jigar Gandhi

## Upload
Upload `index.html`, `style.css`, and `app.js` to the root of `adjigar15607-jigs/Billing`.

## Cloud
Supabase project: Advocate Billing (`brwtgglxitfotchhnzic`).

## First login
Create the owner's user in Supabase Authentication, then log in from the app.

## Important
This is a starter cloud app. Authentication and RLS are enabled. Before production use, add role-based policies and server-side validation.
